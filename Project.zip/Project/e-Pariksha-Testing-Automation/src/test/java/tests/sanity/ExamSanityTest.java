package tests.sanity;

public class ExamSanityTest {

}
